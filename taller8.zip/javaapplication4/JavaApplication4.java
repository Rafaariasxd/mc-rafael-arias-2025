/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication4;

import java.util.Scanner;

/**
 *
 * @author B14
 */
public class JavaApplication4 {

    
     private static final char[] DIGITOS_BASE12 = {
        '0','1','2','3','4','5','6','7','8','9','A','B'
    };

    public static String convertirABase12(long n) {
        if (n == 0) return "0";
        boolean negativo = n < 0;
        if (negativo) n = -n;

        StringBuilder sb = new StringBuilder();
        
        while (n > 0) {
            int resto = (int)(n % 12);
            sb.append(DIGITOS_BASE12[resto]);
            n /= 12;
        }
        if (negativo) sb.append('-');
        return sb.reverse().toString();
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Ingrese un entero en base 10: ");
        long n = sc.nextLong();
        System.out.println("En base 12: " + convertirABase12(n));
        sc.close();
    }
    
    
      
    
    
}
