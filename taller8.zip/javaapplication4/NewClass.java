/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication4;

import java.util.Scanner;

/**
 *
 * @author B14
 */
public class NewClass {
    
      public static long convertirADecimal(String s) {
        if (s == null || s.isEmpty())
            throw new IllegalArgumentException("Entrada vacía");

        s = s.trim();
        boolean negativo = false;

        if (s.charAt(0) == '+' || s.charAt(0) == '-') {
            negativo = (s.charAt(0) == '-');
            s = s.substring(1);
            if (s.isEmpty())
                throw new IllegalArgumentException("Falta el número después del signo");
        }

        
        for (char c : s.toCharArray()) {
            if (c < '0' || c > '5') {
                throw new IllegalArgumentException(
                    "Dígito inválido para base 6: '" + c + "'. Use solo 0..5."
                );
            }
        }

        long valor = 0L;
        long potencia = 1L; 
        
        for (int i = s.length() - 1; i >= 0; i--) {
            int digito = s.charAt(i) - '0';
            valor += digito * potencia;
            potencia *= 6; 
        }

        return negativo ? -valor : valor;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Ingrese un número en base 6: ");
        String entrada = sc.nextLine();

        try {
            long resultado = convertirADecimal(entrada);
            System.out.println("En base 10: " + resultado);
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            sc.close();
        }
    }
    
}
